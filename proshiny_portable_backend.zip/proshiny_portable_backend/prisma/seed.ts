import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
const prisma = new PrismaClient();
async function main() {
  const pass = await bcrypt.hash("Temp123!", 10);
  await prisma.user.upsert({
    where: { email: "admin@proshinycleaningservices.com" },
    update: {},
    create: { role: "admin", name: "ProShiny Admin", email: "admin@proshinycleaningservices.com", phone: "864-607-5372", passwordHash: pass }
  });
  const services = [
    { name: "Residential Standard", code: "RES_STD", durationMinutes: 120, basePriceCents: 12000 },
    { name: "Deep Cleaning", code: "DEEP", durationMinutes: 180, basePriceCents: 20000 },
    { name: "Move In/Out", code: "MOVE", durationMinutes: 240, basePriceCents: 25000 },
    { name: "Office Cleaning", code: "OFFICE", durationMinutes: 180, basePriceCents: 22000 },
    { name: "Carpet Cleaning", code: "CARPET", durationMinutes: 90, basePriceCents: 10000 },
    { name: "Window Cleaning", code: "WINDOWS", durationMinutes: 90, basePriceCents: 9000 }
  ];
  for (const s of services) await prisma.service.upsert({ where: { code: s.code }, update: {}, create: { ...s } });
  await prisma.serviceArea.createMany({
    data: [
      { name: "Camden", state: "NJ", radiusMiles: 25, centerLat: 39.9259, centerLng: -75.1196 },
      { name: "Philadelphia", state: "PA", radiusMiles: 25, centerLat: 39.9526, centerLng: -75.1652 },
      { name: "Delaware", state: "DE", radiusMiles: 25, centerLat: 39.7391, centerLng: -75.5398 }
    ],
    skipDuplicates: true
  });
  console.log("Seed complete.");
}
main().finally(async () => { await prisma.$disconnect(); });
