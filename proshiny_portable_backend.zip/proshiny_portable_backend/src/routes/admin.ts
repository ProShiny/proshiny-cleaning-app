import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { requireAuth, requireRole } from "../security/auth.js";
const prisma = new PrismaClient();
export const router = Router();
router.use(requireAuth);

router.get("/me", (req: any, res) => { res.json({ user: req.user }); });

router.get("/leads", requireRole("admin"), async (_req, res) => {
  const leads = await prisma.lead.findMany({ orderBy: { createdAt: "desc" } });
  res.json(leads);
});

router.get("/bookings", requireRole("admin"), async (_req, res) => {
  const bookings = await prisma.booking.findMany({ orderBy: { createdAt: "desc" } });
  res.json(bookings);
});
