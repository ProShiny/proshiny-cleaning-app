import { Router } from "express";
import Stripe from "stripe";
const router = Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", { apiVersion: "2024-06-20" });

router.post("/create-intent", async (req, res) => {
  const { amount_cents, currency = "usd", metadata } = req.body || {};
  if (!amount_cents) return res.status(400).json({ error: "amount_cents required" });
  try {
    const pi = await stripe.paymentIntents.create({ amount: amount_cents, currency, metadata });
    res.json({ client_secret: pi.client_secret });
  } catch (e: any) {
    res.status(500).json({ error: e?.message || "Stripe error" });
  }
});

export default router;
