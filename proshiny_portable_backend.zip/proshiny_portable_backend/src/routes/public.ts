import { Router } from "express";
import { PrismaClient, BookingStatus } from "@prisma/client";
import { quoteEstimate } from "../utils/quote.js";
import { verifyZapierHmac } from "../utils/zapier.js";

const prisma = new PrismaClient();
export const router = Router();

router.get("/services", async (_req, res) => {
  const services = await prisma.service.findMany({ where: { isActive: true } });
  res.json(services);
});

router.post("/leads", async (req, res) => {
  const { name, email, phone, source, service_code, notes, utm_source, utm_medium, utm_campaign } = req.body || {};
  if (!name || !email) return res.status(400).json({ error: "name and email are required" });
  const lead = await prisma.lead.create({
    data: {
      name, email, phone,
      source: (source || "web"),
      serviceCode: service_code,
      notes,
      utmSource: utm_source,
      utmMedium: utm_medium,
      utmCampaign: utm_campaign
    }
  });
  res.status(201).json(lead);
});

router.post("/quotes/estimate", async (req, res) => {
  const { service_code, home_size_sqft, rooms, bathrooms, addons } = req.body || {};
  if (!service_code) return res.status(400).json({ error: "service_code required" });
  const service = await prisma.service.findUnique({ where: { code: service_code } });
  if (!service) return res.status(404).json({ error: "service not found" });
  const { total, breakdown } = quoteEstimate(service.basePriceCents, { sqft: home_size_sqft, rooms, bathrooms, addons });
  res.json({ estimate_cents: total, breakdown });
});

router.post("/bookings", async (req, res) => {
  const { user_id, service_code, start_at, end_at, address, city, state, zip, notes, price_cents, discount_cents, coupon_code } = req.body || {};
  if (!service_code || !start_at || !end_at || !address || !city || !state || !zip || !price_cents)
    return res.status(400).json({ error: "missing fields" });
  const overlap = await prisma.booking.findFirst({
    where: { startAt: { lte: new Date(end_at) }, endAt: { gte: new Date(start_at) }, status: { in: ["pending","confirmed","in_progress"] } }
  });
  if (overlap) return res.status(409).json({ error: "time slot not available" });
  const booking = await prisma.booking.create({
    data: {
      userId: user_id && user_id !== "guest" ? user_id : undefined,
      serviceCode: service_code,
      startAt: new Date(start_at),
      endAt: new Date(end_at),
      address, city, state, zip,
      notes,
      priceCents: price_cents,
      discountCents: discount_cents || 0,
      couponCode: coupon_code || null,
      status: BookingStatus.pending
    }
  });
  res.status(201).json(booking);
});

router.post("/webhooks/zapier", async (req, res) => {
  const ok = verifyZapierHmac(req);
  if (!ok) return res.status(401).json({ error: "Invalid signature" });
  const { event, data } = req.body || {};
  res.json({ received: true, event, data });
});
