type Params = { sqft?: number; rooms?: number; bathrooms?: number; addons?: string[] };
export function quoteEstimate(basePriceCents: number, p: Params) {
  let total = basePriceCents;
  const breakdown: string[] = [`Base: $${(basePriceCents/100).toFixed(2)}`];
  if (p.sqft && p.sqft > 1500) {
    const extra = Math.ceil((p.sqft - 1500) / 500) * 1500;
    total += extra;
    breakdown.push(`Large home adj.: $${(extra/100).toFixed(2)}`);
  }
  if (p.bathrooms && p.bathrooms > 2) {
    const extra = (p.bathrooms - 2) * 1000;
    total += extra;
    breakdown.push(`Extra bathrooms: $${(extra/100).toFixed(2)}`);
  }
  if (p.addons && p.addons.length) {
    for (const a of p.addons) {
      const cost = addonCost(a);
      total += cost;
      breakdown.push(`${a}: $${(cost/100).toFixed(2)}`);
    }
  }
  return { total, breakdown };
}
function addonCost(a: string) {
  switch (a) { case "windows": return 6000; case "inside_oven": return 3000; case "inside_fridge": return 3000; case "carpet_room": return 4000; default: return 0; }
}
