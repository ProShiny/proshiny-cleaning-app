import crypto from "crypto";
export function verifyZapierHmac(req: any) {
  const secret = process.env.ZAPIER_WEBHOOK_SECRET || "";
  const signature = req.body?.signature || req.headers["x-zapier-signature"] || "";
  if (!secret || !signature) return false;
  const payload = JSON.stringify({ event: req.body?.event, data: req.body?.data });
  const hmac = crypto.createHmac("sha256", secret).update(payload).digest("hex");
  return hmac === signature;
}
