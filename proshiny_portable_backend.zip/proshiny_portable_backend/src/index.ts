import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import { PrismaClient } from "@prisma/client";
import { router as publicRoutes } from "./routes/public.js";
import { router as adminRoutes } from "./routes/admin.js";
import { authRouter } from "./security/auth.js";
import payments from "./routes/payments.js";

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 8787;

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

const limiter = rateLimit({ windowMs: 60 * 1000, limit: 120 });
app.use(limiter);

app.get("/health", async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ ok: true, time: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.use("/api/public", publicRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/auth", authRouter);
app.use("/api/payments", payments);

app.use((err: any, _req: any, res: any, _next: any) => {
  console.error(err);
  res.status(500).json({ error: "Internal Server Error", detail: String(err) });
});

app.listen(PORT, () => console.log(`ProShiny API running on :${PORT}`));
